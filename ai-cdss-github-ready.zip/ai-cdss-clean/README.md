# Explainable AI-Based Clinical Decision Support System for Doctors (AI-CDSS)

An end-to-end, doctor-in-the-loop web application combining patient electronic medical record management, OCR medical report extraction, rules-based laboratory interpretation, 30-day hospital readmission risk prediction using XGBoost, Explainable AI (SHAP, PDP, ICE), and RAG-grounded clinical guideline retrieval with LLM summaries.

---

> [!IMPORTANT]
> ### Clinical Decision Support Disclaimer
> This system is designed solely as a **decision support prototype** for certified clinicians and **does not** claim to autonomously diagnose diseases or prescribe medications. All generated summaries, statistical probabilities, and risk assessments require final physician review and validation.

---

## 1. Project Overview & Architecture

### High-Level System Architecture
```
                  +-----------------------------------+
                  |        Doctor / Clinician         |
                  +-----------------+-----------------+
                                    |
                                    v
                  +-----------------------------------+
                  |  React + Vite Frontend (JS)       |
                  |  Healthcare / Medical Green UI    |
                  +-----------------+-----------------+
                                    | REST APIs (Axios + JWT)
                                    v
                  +-----------------------------------+
                  |    FastAPI Python Backend         |
                  |  Auth, CRUD, Service Integrator   |
                  +--------+-----------------+--------+
                           |                 |
        +------------------+                 +------------------+
        |                                                       |
        v                                                       v
+-------------------------------+               +-------------------------------+
|     PostgreSQL Database       |               |     Clinical AI Subsystems    |
| • users (doctors)             |               | • XGBoost Readmission Risk    |
| • patients                    |               | • SHAP / XAI Engine (W10)     |
| • medical_history             |               | • Tesseract OCR Reports (W2)  |
| • reports (W2)                |               | • Rules Lab Engine (W4)       |
| • lab_results (W4)            |               | • RAG Vector DB (FAISS) (W5)  |
| • predictions & logs (W9-11)  |               | • Clinical LLM Assistant (W7) |
+-------------------------------+               +-------------------------------+
```

---

## 2. Technology Stack

| Layer | Technologies | Description |
| :--- | :--- | :--- |
| **Frontend** | React 18, Vite, JavaScript (ES6+), Tailwind CSS, React Router v6, Axios, Lucide React | Clean healthcare visual theme inspired by modern medical portals (white background, medical green accents, card layout) |
| **Backend** | Python 3.10+, FastAPI, SQLAlchemy 2.0, Pydantic v2, PostgreSQL, Uvicorn | High-performance RESTful API with JWT auth and relational data layer |
| **Authentication** | JWT (JSON Web Tokens), Passlib, Bcrypt | Secure role-based doctor authentication |
| **Machine Learning** | Scikit-learn, XGBoost, Pandas, NumPy, Joblib | 30-day hospital readmission binary classifier on UCI Diabetes 130-US Hospitals dataset |
| **Explainable AI (Roadmap)** | SHAP, PDP, ICE, Permutation Importance | Local and global interpretability for clinicians |
| **RAG & NLP (Roadmap)** | Sentence Transformers, FAISS / Chroma, LangChain | Semantic search over trusted clinical guidelines |
| **OCR (Roadmap)** | Tesseract OCR / PyTesseract | Text extraction from PDF & image medical reports |

---

## 3. Project Directory Structure

```
ai-cdss/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── __init__.py          # API route aggregator
│   │   │   ├── auth.py              # Doctor Register, Login, Me endpoints
│   │   │   └── patients.py          # Patient CRUD & Medical History APIs
│   │   ├── core/
│   │   │   ├── __init__.py
│   │   │   ├── config.py            # Pydantic Settings & environment loader
│   │   │   └── security.py          # Bcrypt hashing & JWT token handler
│   │   ├── database/
│   │   │   ├── __init__.py
│   │   │   └── session.py           # SQLAlchemy database session & engine
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── user.py              # User (Doctor) SQLAlchemy model
│   │   │   └── patient.py           # Patient & MedicalHistory models
│   │   ├── schemas/
│   │   │   ├── __init__.py
│   │   │   ├── user.py              # UserRegister, UserLogin, Token schemas
│   │   │   └── patient.py           # PatientCreate, PatientOut schemas
│   │   ├── services/
│   │   └── main.py                  # FastAPI entrypoint & CORS middleware
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx           # Medical brand header & doctor badge
│   │   │   ├── Sidebar.jsx          # Navigation & 12-week module status
│   │   │   ├── ProtectedRoute.jsx   # Auth route guard
│   │   │   ├── StatCard.jsx         # Clinical metric card
│   │   │   └── ClinicalDisclaimer.jsx # Medical safety disclaimer banner
│   │   ├── context/
│   │   │   └── AuthContext.jsx      # Doctor session & JWT state
│   │   ├── services/
│   │   │   └── api.js              # Axios client with JWT interceptor
│   │   ├── pages/
│   │   │   ├── Login.jsx            # Doctor login with demo credential filler
│   │   │   ├── Register.jsx         # Doctor registration form
│   │   │   ├── Dashboard.jsx        # Doctor dashboard & stats overview
│   │   │   ├── Patients.jsx         # Searchable patient directory
│   │   │   ├── AddPatient.jsx       # Patient registration form
│   │   │   ├── EditPatient.jsx      # Patient update form
│   │   │   └── PatientDetails.jsx   # Patient profile & medical history
│   │   ├── App.jsx                  # Main routing & application layout
│   │   ├── index.css                # Medical green design system
│   │   └── main.jsx                 # React DOM mount
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── ml/
│   ├── data/                       # UCI Diabetes dataset storage
│   ├── models/                     # Trained XGBoost model & preprocessor
│   ├── outputs/                    # metrics.json & evaluation artifacts
│   └── scripts/
│       ├── download_or_generate_dataset.py # UCI dataset fetcher / generator
│       ├── preprocess.py           # Feature engineering & scaling
│       ├── train.py                # XGBoost baseline training script
│       └── predict_sample.py       # Sample clinical risk inference
│
├── rag/
│   ├── documents/                  # Clinical guidelines & reference docs
│   ├── embeddings/
│   └── vector_db/
│
├── docs/
│   └── week1_demo_guide.md         # Mentor evaluation script
│
├── .env.example                    # Environment configuration template
├── .env                            # Active environment configuration
├── docker-compose.yml              # Local PostgreSQL container service
└── README.md
```

---

## 4. Steps Completed Till Now (Week 1: Core Foundation & ML Baseline)

### 4.1 Backend & Authentication Foundation
- [x] **FastAPI Backend Setup**: Configured modular application structure with `pydantic-settings`, CORS middleware, and automated schema generation.
- [x] **Database & Models**: Created SQLAlchemy models for `User` (Doctors) and `Patient` / `MedicalHistory`. Configured support for both PostgreSQL (`postgresql://...`) and SQLite local fallback.
- [x] **Security & JWT**: Implemented password hashing with `bcrypt` / `passlib` and JWT token creation/decoding with route protection dependencies (`get_current_user`).
- [x] **Patient Management APIs**:
  - `POST /api/auth/register` & `POST /api/auth/login`
  - `GET /api/auth/me`
  - `GET /api/patients` (with query-based search and gender filtering)
  - `POST /api/patients` (with optional initial medical condition)
  - `GET /api/patients/{id}` (returns complete demographic & medical history profile)
  - `PUT /api/patients/{id}` & `DELETE /api/patients/{id}`
  - `POST /api/patients/{id}/history` (appends medical diagnoses to timeline)
  - `GET /api/patients/stats/summary` (dashboard statistics)

### 4.2 Frontend Application (React + Vite)
- [x] **Medical Green Design Theme**: Built custom CSS design system using Tailwind CSS with medical green tokens (`#0f4c3a`, `#0e7c5b`, `#ecfdf5`), clean cards, modern typography, and zero clutter.
- [x] **Doctor Authentication Flow**: Login and Registration pages with JWT storage, persistent session management, and quick demo credentials filler.
- [x] **Dashboard**: Real-time stats (Total Assigned Patients, Tracked Diagnoses, ML Readmission status, Clinical Safety), recent admissions table, and 12-week roadmap status tracker.
- [x] **Patient Directory**: Searchable by patient name, phone, or email, with client-side gender filter, profile access, and edit.
- [x] **Patient Registration, Edit & Medical History**: Forms for registering and editing patients; medical conditions with status (`Active`, `Chronic`, `Resolved`).
- [x] **Clinical Safety Disclaimer Component**: Explicit doctor-in-the-loop warning banner rendered across all clinical views.

### 4.3 Machine Learning Baseline (UCI Diabetes 130-US Hospitals)
- [x] **Dataset Handling**: `download_or_generate_dataset.py` fetches the UCI Diabetes 130-US Hospitals dataset or creates a statistically faithful representative dataset matching the exact schema.
- [x] **Preprocessing Pipeline**: Handled encounter features, ICD-9 diagnosis groupings (Circulatory, Respiratory, Digestive, Diabetes, etc.), categorical encoding for diabetes medications (`insulin`, `metformin`, etc.), and standard scaling for numeric features.
- [x] **Target Definition**: Binary classification for 30-day hospital readmission (`<30` as 1, else 0).
- [x] **Model Training**: Trained XGBoost Classifier with `scale_pos_weight` to address class imbalance. Computed Accuracy, Precision, Recall, F1, and ROC-AUC metrics.
- [x] **Model Artifacts**: Saved trained model to `ml/models/xgboost_readmission.joblib`, preprocessor to `ml/models/preprocessor.joblib`, metrics to `ml/outputs/metrics.json`, and feature names to `ml/outputs/feature_list.json`.

---

## 5. How to Run the Project (Week 1)

### Prerequisites
- Python 3.10+
- Node.js 18+ & npm
- PostgreSQL (Optional; SQLite fallback is preconfigured in `.env` for zero-friction local testing)

---

### Step 0: PostgreSQL (recommended)
```bash
docker compose up -d postgres
```
Copy `.env.example` to `.env`. Default URL: `postgresql://postgres:postgres@localhost:5432/ai_cdss`. If Postgres is unavailable, set `DATABASE_URL=sqlite:///./ai_cdss.db`.

### Step 1: Backend Setup
```bash
# From workspace root
python run_backend.py

# OR manually from the backend folder:
cd backend
uvicorn app.main:app --reload --port 8000
```
*The backend API documentation is available at `http://localhost:8000/docs`.*

---

### Step 2: Frontend Setup
```bash
# Open a new terminal in workspace root
cd frontend

# Install npm dependencies
npm install

# Start Vite development server
npm run dev
```
*Open your browser at `http://localhost:5173` to access the Doctor Portal.*

---

### Step 3: Run Machine Learning Pipeline
```bash
# Open a new terminal in workspace root
# Train XGBoost Readmission Model
python ml/scripts/train.py

# Run sample patient risk prediction inference
python ml/scripts/predict_sample.py
```

---

## 6. Detailed Future Roadmap & AI Hand-off Guide (Weeks 2–12)

> [!NOTE]
> **Instructions for Continuing AI / Team Members**:
> When continuing this project, pick up from **Week 2** in the exact chronological order below. Keep files modular and token-efficient. Do not create unnecessary abstractions.

```
+-----------------------------------------------------------------------------------+
| 4-Member Team Ownership:                                                          |
| • Member 1: ML + XGBoost + Explainable AI (Weeks 1, 9, 10)                        |
| • Member 2: OCR + NLP + RAG (Weeks 2, 3, 5, 6, 7)                                 |
| • Member 3: FastAPI + PostgreSQL + Authentication (Weeks 1, 4, 8, 11)             |
| • Member 4: React + UI + Integration (Weeks 1, 8, 11, 12)                         |
+-----------------------------------------------------------------------------------+
```

### Week 2: Medical Report Upload and OCR (Member 2)
- **Objective**: Allow doctors to upload lab/clinical reports (PDF or images) and extract raw text using OCR.
- **Database Table**: Add `reports` table (`id`, `patient_id`, `filename`, `file_path`, `report_type`, `extracted_text`, `uploaded_at`).
- **Backend**: Implement `POST /api/patients/{id}/reports` with multipart file upload. Use `pytesseract` / `pdf2image` to extract text and store raw text in the database.
- **Frontend**: Add Report Upload dropzone in `PatientDetails.jsx` and display raw extracted text tab.

### Week 3: Clinical NLP & Structured Information Extraction (Member 2)
- **Objective**: Parse extracted OCR text to identify medical conditions, medications, lab values, and clinical dates.
- **Implementation**: Write regex and clinical entity parsing routines (or lightweight spaCy/scispacy). Present extracted entities to the doctor for one-click approval before saving to `medical_history`.

### Week 4: Deterministic Rules-Based Laboratory Analysis Engine (Member 3)
- **Objective**: Build a deterministic rules engine comparing numeric lab values against standard clinical reference ranges.
- **Important**: Do NOT ask an LLM to determine if a number is normal. Use explicit reference bounds (e.g. Fasting Glucose 70–99 mg/dL = Normal, 100–125 = Pre-diabetic, >=126 = Potentially High; HbA1c <5.7% Normal, 5.7–6.4% Prediabetes, >=6.5% Elevated).
- **Output Structure**: Test Name, Numeric Result, Unit, Reference Range, Status (`Normal`, `Potentially Elevated`, `Potentially Low`), Clinical Basis.
- **Database Table**: `lab_results` (`id`, `patient_id`, `test_name`, `value`, `unit`, `reference_range`, `status`, `test_date`).

### Week 5: RAG Foundation — Document Ingestion & Vector Retrieval (Member 2)
- **Objective**: Curate trusted clinical guideline documents (ADA Standards of Diabetes Care, AHA Cardiology Guidelines) into `rag/documents/`.
- **Implementation**: Chunk documents using recursive character splitter, compute embeddings using `sentence-transformers/all-MiniLM-L6-v2`, and store in local FAISS vector index (`rag/vector_db/`). Implement semantic search endpoint `POST /api/rag/search`.
- **Current prototype**: Two source-linked guideline summaries are indexed locally. `POST /api/rag/reindex` rebuilds the index; `POST /api/rag/search` returns source, section, excerpt, relevance score, and source URL only. No LLM answer is generated in Week 5.

### Week 6: RAG + LLM Integration for Question Answering (Member 2)
- **Objective**: Connect retrieval results to an LLM (Gemini API or local Ollama) to answer doctor questions based strictly on retrieved guideline chunks.
- **Requirements**: Prompt template must enforce: *"Use only provided retrieved context. Cite source document and section. If context is insufficient, state that clearly. Do not prescribe or diagnose."*

### Week 7: AI Clinical Assistant (Member 2 & Member 4)
- **Objective**: Build a conversational assistant interface inside the patient view where doctors can ask guideline questions, summarize multi-page patient records, and generate draft clinical discharge notes.

### Week 8: Mid-Term MVP Integration & Review (All Members)
- **Objective**: Full end-to-end integration test: Doctor Login -> Patient Record -> Report Upload -> OCR Extraction -> Lab Rule Analysis -> RAG Guideline Q&A -> AI Summary.

### Week 9: Advanced ML Improvement & Calibration (Member 1)
- **Objective**: Enhance the XGBoost readmission pipeline.
- **Tasks**: Feature engineering, hyperparameter tuning via GridSearchCV/RandomizedSearchCV, class weight optimization, and probability calibration using `CalibratedClassifierCV` (Isotonic / Sigmoid). Generate calibration curves and Brier score.

### Week 10: Comprehensive Explainable AI (SHAP, PDP, ICE, Counterfactuals) (Member 1 & Member 4)
- **Objective**: Integrate multi-method model interpretability for clinicians.
  - **SHAP Local Explanation**: Force plots / waterfall plots showing exact features increasing or decreasing readmission risk for the selected patient.
  - **SHAP Global Importance**: Summary plot of top 20 dataset features.
  - **Partial Dependence Plots (PDP)**: Show general model prediction curve across key continuous features (e.g. `time_in_hospital`, `num_medications`).
  - **Individual Conditional Expectation (ICE)**: Display individual prediction trajectory variations.
  - **Illustrative Counterfactuals**: "If inpatient encounters were 0 instead of 3, predicted readmission probability decreases from 62% to 28%." (Framed as illustrative model behavior, not medical advice).

### Week 11: Out-of-Distribution (OOD) Warning & Full System Unification (All Members)
- **Objective**: Add data quality and out-of-distribution detection (e.g. Mahalanobis distance or Isolation Forest). If a patient input falls outside typical training ranges, display: *"Caution: Input differs substantially from training data distribution."*

### Week 12: Rigorous Evaluation, Testing & Final Documentation (All Members)
- **Objective**: Run unit tests (`pytest`), API validation tests, UI responsive checks, RAG faithfulness evaluation, and finalize CSE project thesis documentation.

---

## 7. Medical Safety & Ethical Guidelines

1. **Always Doctor-in-the-Loop**: The software acts as an analytical aide and decision support tool. It never replaces the professional judgement of a qualified healthcare practitioner.
2. **Clear Separation of Concerns**: Numerical risk is calculated by XGBoost; explanations are derived from SHAP; guideline evidence is retrieved from verified documents via RAG; natural language text is generated by LLMs. The LLM is never asked to guess numbers or diagnose autonomously.
3. **Transparent Limitations**: All uncertainty, calibration warnings, and missing features are explicitly surfaced to the doctor.

---

## 8. License & Academic Disclaimer
Developed for Final-Year Computer Science and Engineering (CSE) Capstone Project.
For academic and decision-support research demonstration only.
